import crypto from 'node:crypto';

export default async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  let body;
  try { body = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Invalid request' }); }
  const expectedCode = process.env.ADMIN_CODE;
  const secret = process.env.ADMIN_SECRET;
  if (!expectedCode || !secret) return json(503, { error: 'Admin service is not configured' });
  if (body.action !== 'login' || typeof body.code !== 'string' || body.code.length > 32) return json(400, { error: 'Invalid request' });
  const a = Buffer.from(body.code);
  const b = Buffer.from(expectedCode);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return json(401, { error: 'Invalid code' });
  const payload = Buffer.from(JSON.stringify({ exp: Date.now() + 8 * 60 * 60 * 1000 })).toString('base64url');
  const signature = crypto.createHmac('sha256', secret).update(payload).digest('hex');
  return json(200, { token: `${payload}.${signature}` });
};

function json(statusCode, body) {
  return { statusCode, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', 'Access-Control-Allow-Origin': '*' }, body: JSON.stringify(body) };
}
